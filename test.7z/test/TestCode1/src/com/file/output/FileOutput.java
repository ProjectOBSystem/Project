package com.file.output;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class FileOutput {
	
		public static void main(String[] args) throws IOException {
		String CurrentLine; 
		ArrayList<Bean> List = new ArrayList<Bean>();
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\paliw\\Desktop\\textFile.txt"));
		ArrayList<Integer> index_List = new ArrayList<Integer>();
		while ((CurrentLine = br.readLine()) != null) {
		  System.out.println(CurrentLine);
		  if(CurrentLine.length() == 0){
				continue;
		  }
		  String[] split = CurrentLine.split(":");
		  double weightLimit = Double.parseDouble(split[0].trim());
		
		  String[] stringBeans = split[1].trim().split(" ");
		  double weight=0;
		  for(String loop:stringBeans){
			  String[] Package_Beans = loop.trim().split(",");
			  int index = Integer.parseInt(Package_Beans[0].substring(1));
			 weight  = Double.parseDouble(Package_Beans[1]);
				double cost = Double.parseDouble(Package_Beans[2].substring(1,Package_Beans[2].length()-1).trim());
		
			 Bean Beans = new Bean(index,weight,cost);
			 
			 List.add(Beans);
			 
			 
		  }
		  box file = new box(weightLimit, List);
		  index_List= file.createbox();	  
	
	  	}
		br.close();
		System.out.println(index_List.toString().replace("[", "").replace("]", "").replace(", ", ","));
		
	}
}
	
	
	
