package com.file.output;

import java.util.ArrayList;
import java.util.Collections;






public class box {
	double weightlimit;
	static ArrayList<Bean> List;
	ArrayList<ArrayList<Bean>>pairs;

	

	public box(double weightLimit, ArrayList<Bean> list) {
		// TODO Auto-generated constructor stub
		weightlimit = weightLimit;
		List = list;
		pairs = new ArrayList<ArrayList<Bean>>();
	}

	public ArrayList<Integer> createbox(){

		pairs = all_possible_pairs();
		ArrayList<Integer> index = new ArrayList<Integer>();
		boolean Flag = true;
		if(pairs.size() == 0){
			System.out.println("-");
		}else{
			ArrayList<Bean> finalList = finalPair();
			Collections.sort(finalList);
			for (Bean loop : finalList) {
				if(Flag){
					index.add(loop.getItem_id());
								
					Flag = false;
				}else{
					index.add(loop.getItem_id());
					
				}
			}
			//printOutput(finalList);
			
		}
		return index;
	}
	public ArrayList<ArrayList<Bean>> all_possible_pairs(){
		
		for(int i = 0; i < List.size(); i++){
			Bean bean = List.get(i);
			int size=pairs.size();
			
			for(int j = 0; j < size; j++){
				ArrayList<Bean> new_list = pairs.get(j);
				
				ArrayList<Bean> final_list = new ArrayList<Bean>(new_list);
				final_list.add(bean);
				pairs.add(final_list);
			}
			
			ArrayList<Bean> temp_list = new ArrayList<Bean>();
			temp_list.add(bean);
			pairs.add(temp_list);	
		}
		
		return pairs;
	}
	public ArrayList<Bean> finalPair(){
		ArrayList<Bean> final_pair = new ArrayList<Bean>();
		double cost = 0;
		double weight = 100; //max weight is 100
		for(ArrayList<Bean> list : pairs){
			double finalweight=0;
			double finalCost=0;
			for(Bean i : list){
				finalweight += i.getItem_weight();
			}
			
			
			if(finalweight > weightlimit){
				continue;
			}else{
				for(Bean i : list){
					finalCost += i.getItem_cost();
				}
				
				if(finalCost > cost){
					cost = finalCost;
					final_pair = list;
					weight = finalweight;
				}else if(finalCost == cost){	
					if(finalweight < weight){
						cost = finalCost;
						final_pair = list;
						weight = finalweight;
					}
				}
			}
		}
		return final_pair;
	}

public void printOutput(ArrayList<Bean> Beans){
		
		ArrayList<Integer> index = new ArrayList<Integer>();
		boolean Flag = true;
		for (Bean loop : Beans) {
			if(Flag){
				index.add(loop.getItem_id());
							
				Flag = false;
			}else{
				index.add(loop.getItem_id());
				
			}
		}
		System.out.println(index.toString().replace("[", "").replace("]", "").replace(", ", ","));
	}
}
