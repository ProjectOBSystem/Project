package test;

import java.io.IOException;

public class Test {
	static int ways(int m, int n)
	{
	    
	    int[][]counter = new int[m][n];
	    
	    for (int i = 0; i < m; i++){
	    	
	       counter[i][0] = 1;
	      if(i==3){
	      
	        	 for (int j = 0; j < m; j++){
	        		
	        		 counter[3][j] = 1 ;
	        	
	        	 }	        	
	        }
	        
	    }
	   
	    
	   
	    for (int j = 0; j < n; j++){
	    	
	    	counter[0][j] = 1;
	    	 if(j==3){
	    		
	        	 for (int i = 1; i < n; i++)
	        	 {
	        		 
	        		 counter[i][3] = 1;
	        	
	        	 }
	        }
	    }
	       
	    
	   
	   
	    for (int i = 1; i < m; i++)
	    {
	
	        for (int j = 1; j < n; j++)
	        	 {
	            	
	           counter[i][j] =counter[i-1][j] +counter[i][j-1]+counter[i-1][j-1]+counter[i][j];
	            
	        	 }
	      	
	    }
	  
	    return counter[m-1][n-1];
	}
	
	public static void main(String[] args) throws IOException {
	
	    int number= ways(4, 4);
	    
	    System.out.println(number);
	}
}
