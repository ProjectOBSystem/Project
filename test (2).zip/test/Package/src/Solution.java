
public @interface Solution {

}
