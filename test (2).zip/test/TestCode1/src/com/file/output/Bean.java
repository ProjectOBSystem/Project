package com.file.output;

public class Bean implements Comparable<Bean> {
	private int item_id;
private double item_weight;

private double item_cost;


public Bean() {
	super();
	// TODO Auto-generated constructor stub
}

public Bean( int item_id,double item_weight, double item_cost) {
	super();
	this.item_weight = item_weight;
	this.item_id = item_id;
	this.item_cost = item_cost;
}

public double getItem_weight() {
	return item_weight;
}
public void setItem_weight(double item_weight) {
	this.item_weight = item_weight;
}
public int getItem_id() {
	return item_id;
}
public void setItem_id(int item_id) {
	this.item_id = item_id;
}
public double getItem_cost() {
	return item_cost;
}
public void setItem_cost(double item_cost) {
	this.item_cost = item_cost;
}

@Override
public String toString() {
	return "Bean [item_weight=" + item_weight + ", item_id=" + item_id
			+ ", item_cost=" + item_cost + "]";
}

@Override
public int compareTo(Bean arg0) {
	// TODO Auto-generated method stub
	 return new Double(item_weight).compareTo(arg0.item_weight );
}

public int compareTo1(Bean arg0) {
	// TODO Auto-generated method stub
	 return this.item_id-arg0.item_id;
}
}
