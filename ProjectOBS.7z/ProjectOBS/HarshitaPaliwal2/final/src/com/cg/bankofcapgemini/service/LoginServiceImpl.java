package com.cg.bankofcapgemini.service;



import com.cg.bankofcapgemini.dao.LoginDao;
import com.cg.bankofcapgemini.dao.LoginDaoImpl;


import com.cg.bankofcapgemini.exception.UserException;

public class LoginServiceImpl implements LoginService {
	private static LoginDao logindao = new LoginDaoImpl();
	@Override
	public boolean check_login(String user_id, String password) throws UserException {
		// TODO Auto-generated method stub
			
				return logindao.check_login(user_id, password);
		
	}
	public void lock(String user_id) throws UserException{
		logindao.lock(user_id);
	}
	@Override
	public long forgotpassword(String user_id,String secret_answer) throws UserException {
		// TODO Auto-generated method stub
		return logindao.forgotpassword(user_id,secret_answer);
	}
	@Override
	public double getBalance(String user_id) throws UserException {
		// TODO Auto-generated method stub
		return logindao.getBalance(user_id);
	}
	@Override
	public String getName(String user_id) throws UserException {
		// TODO Auto-generated method stub
		return logindao.getName(user_id);
	}
	@Override
	public boolean validateuser(String user_id, long user_code, long system_code) {
		// TODO Auto-generated method stub
		return logindao.validateuser(user_id, user_code, system_code);
	}
	@Override
	public int getAccountId(String user_id) throws UserException {
		// TODO Auto-generated method stub
		return logindao.getAccountId(user_id);
	}
	@Override
	public void lock_counter(String account, int counter) throws UserException {
		logindao.lock_counter(account, counter);
		
	}
	@Override
	public int lock_Status(String account) throws UserException {
		// TODO Auto-generated method stub
		return logindao.lock_Status(account);
	}

	
}
