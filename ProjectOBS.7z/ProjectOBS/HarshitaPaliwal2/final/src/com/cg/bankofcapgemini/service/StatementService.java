package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.exception.UserException;

public interface StatementService {
	public List<TransactionDetails> miniStatement(String user_id)throws UserException;	
	
	public List<TransactionDetails> detailStatement(String user_id)throws UserException;

}
