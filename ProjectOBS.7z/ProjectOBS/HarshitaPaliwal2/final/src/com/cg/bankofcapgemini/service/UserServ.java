package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.dto.User;
import com.cg.bankofcapgemini.dto.otherBanks;

public interface UserServ {
	public String getTransPass(User u);
	public boolean UpdateUserAccount(int accNo,int amm);
	public List<otherBanks> getAllBanks(String name);
	public boolean checkAccountNum(int accNum);
	public boolean UpdatePayeeAccount(int accNo,int amm,TransactionDetails transaction);
}
