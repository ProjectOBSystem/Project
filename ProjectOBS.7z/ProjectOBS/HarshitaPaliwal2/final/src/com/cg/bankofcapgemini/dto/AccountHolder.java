package com.cg.bankofcapgemini.dto;


public class AccountHolder {
	private String name;
	private String address;
	private String email;
	private String mobile;
	private String accounttype;
	private double balance;
	private String pancard;
	private String password;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPetname() {
		return petname;
	}
	public void setPetname(String petname) {
		this.petname = petname;
	}
	private String petname;
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	public AccountHolder(String name, String address, String email,
			String mobile, String accounttype, double balance, String pancard) {
		super();
		this.name = name;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
		this.accounttype = accounttype;
		this.balance = balance;
		this.pancard = pancard;
	}
	public AccountHolder() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "AccoutHolder [name=" + name + ", address=" + address
				+ ", email=" + email + ", mobile=" + mobile + ", accounttype="
				+ accounttype + ", balance=" + balance + ", pancard=" + pancard
				+ "]";
	}

	
	
}
