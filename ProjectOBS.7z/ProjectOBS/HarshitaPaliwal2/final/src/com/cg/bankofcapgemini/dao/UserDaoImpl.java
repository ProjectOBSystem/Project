package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.dto.User;
import com.cg.bankofcapgemini.dto.otherBanks;
import com.cg.bankofcapgemini.factory.DBUtil;


public class UserDaoImpl implements UserDao {

	@Override
	public String getTransPass(User u) {
		// TODO Auto-generated method stub
		
		String t=null;
		Connection con3=null;
		try {
			con3=DBUtil.getConnection();
			String q4="select Transaction_Password from UserTable where Account_Id=?";
			PreparedStatement pt4=con3.prepareStatement(q4);
			pt4.setInt(1,u.getAccNo());
			System.out.println("get acc is "+u.getAccNo());
			System.out.println("in getTransPass");
			ResultSet rs=pt4.executeQuery();
			while(rs.next()) 
			{
				
				 User m=new User();
				t=rs.getString("Transaction_Password");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				con3.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return t;
		
	}
//INTO ACCOUNT MASTER
	@Override
	public boolean UpdateUserAccount(int accNo,int amm) {
		int t=0;
		Connection con3=null;
		boolean flag=false;
		try {
			
			con3=DBUtil.getConnection();
			String q3="select account_Balance from account_master where Account_Id=?";
			PreparedStatement pt3=con3.prepareStatement(q3);
			pt3.setInt(1,accNo);
			ResultSet rs=pt3.executeQuery();
			System.out.println("UpdateUserAccount");
			while(rs.next()) 
			{
				t=rs.getInt("account_balance");
				break;
			}
			System.out.println("balance5555= :"+t+"888==:"+amm);
			if(t<amm) {
				flag=true;
			}
			else {
			flag=false;
			System.out.println(t);
			String q4="update  account_master set Account_Balance=? where Account_Id=?";
			int AccountBal=t-amm;
			PreparedStatement pt4=con3.prepareStatement(q4);
			pt4.setInt(1,AccountBal);
			pt4.setInt(2,accNo);
			int i=pt4.executeUpdate();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				con3.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
		
			
		

	
	
	}
	
	
	
	public boolean UpdatePayeeAccount(int accNo,int amm,TransactionDetails transaction) {
		int t=0;
		boolean flag=false;
		boolean flag2=false;
		Connection con3=null;
		try {
			
			con3=DBUtil.getConnection();
			String q3="select account_Balance from account_master where Account_Id=?";
			PreparedStatement pt3=con3.prepareStatement(q3);
			pt3.setInt(1,accNo);
			ResultSet rs=pt3.executeQuery();
			System.out.println("UpdateUserAccount");
			while(rs.next()) 
			{
				t=rs.getInt("account_balance");
				break;
			}
			System.out.println(t);
			String q4="update  account_master set Account_Balance=? where Account_Id=?";
			int AccountBal=t+amm;
			PreparedStatement pt4=con3.prepareStatement(q4);
			pt4.setInt(1,AccountBal);
			pt4.setInt(2,accNo);
			int i=pt4.executeUpdate();
			if(i==1)
				flag=true;
			
			
			String q6="insert into transactions values(trans_seq.nextval,?,sysdate,'C',?,?)";
			PreparedStatement pt6=con3.prepareStatement(q6);
			pt6.setString(1,transaction.getTran_Description());
			pt6.setInt(2,amm);
			pt6.setInt(3,accNo);
			pt6.executeUpdate();
			
			String q5="update transactions set transactiontype='C' where Account_Id=?";
			PreparedStatement pt5=con3.prepareStatement(q5);
			pt5.setInt(1,accNo);
			ResultSet rs2=pt5.executeQuery();
			System.out.println("UpdateUserAccount");
			if(rs2.next()&& flag==true) 
			{
				flag2=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				con3.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return flag;
	
	}
	
	
	

	
	
	
	
	
	
	
	

	public boolean checkAccountNum(int accNum) {
		// TODO Auto-generated method stub
		boolean flag = false;

		try (Connection con = DBUtil.getConnection()) {

			PreparedStatement ps = con
					.prepareStatement("Select * from account_master where account_id=?");
			ps.setInt(1, accNum);
			ResultSet res = ps.executeQuery();
			System.out.println("checked##########");
			if (res.next() == true) {
				flag = true;
			} else {
				flag = false;

			}
		} catch (Exception e1) {

			e1.printStackTrace();

		}

		return flag;
	}
	@Override
	public List<otherBanks> getAllBanks(String name) {
		List<otherBanks> myList = new ArrayList<otherBanks>();
		int t=0;
		Connection con3=null;
		try {
			con3=DBUtil.getConnection();
			System.out.println(name);
			String q3="Select * from myaccountanotherbank where name= ?";
			PreparedStatement pstm=con3.prepareStatement(q3);
			
			pstm.setString(1,name);
			ResultSet res = pstm.executeQuery();
			System.out.println(res.next());
			
			while (res.next()) {
				otherBanks details = new otherBanks();
				details.setAccount_id(res.getInt("account_id"));
				details.setBank_name(res.getString("bankname"));
				System.out.println(details.getBank_name());
				System.out.println(details.getAccount_id());
				myList.add(details);
				
			}
			System.out.println(myList);
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				con3.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return myList;
		}
	
	
	

	public int getTransactionId() {
		int tid=0;
		java.sql.Statement st;
		try {
			Connection con=DBUtil.getConnection();
			String q="select trans_seq.nextval from dual";
			st = con.createStatement();
			ResultSet rs=st.executeQuery(q);
			while(rs.next()) 
			   {
				  tid=rs.getInt(1);
				  return tid;
			   }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tid;
	}

	

}
