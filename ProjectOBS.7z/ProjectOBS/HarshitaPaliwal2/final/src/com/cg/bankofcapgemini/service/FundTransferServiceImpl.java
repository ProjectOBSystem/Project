package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.dao.FundTransferDao;
import com.cg.bankofcapgemini.dao.FundTransferDaoImpl;
import com.cg.bankofcapgemini.dto.FundTransfer;



public class FundTransferServiceImpl implements FundTransferService {
FundTransferDao fdao=new FundTransferDaoImpl();
	@Override
	public void insert(FundTransfer ft) {
		fdao.insert(ft);
		
	}

}
