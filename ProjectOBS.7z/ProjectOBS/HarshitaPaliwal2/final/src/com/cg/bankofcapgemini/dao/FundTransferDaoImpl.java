package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bankofcapgemini.dto.FundTransfer;
import com.cg.bankofcapgemini.factory.DBUtil;

public class FundTransferDaoImpl implements FundTransferDao {
	
	@Override
	public void insert(FundTransfer ft) {
		Connection con=null;
		try {
			con=DBUtil.getConnection();
			String q="insert into Fund_Transfer values(?,?,?,?,?)";
			PreparedStatement pt=con.prepareStatement(q);
			pt.setInt(1,getFundTransferId());
			pt.setInt(2,ft.getAccount_ID());
			pt.setInt(3,ft.getPayee_Account_ID());
			String q3="Select sysdate from dual";
			java.sql.Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(q3);
			while(rs.next()) 
			{
				pt.setDate(4,rs.getDate(1));	
			}
			pt.setFloat(5,ft.getTransfer_Amount());
			int i=pt.executeUpdate();
			if(i==1)
				System.out.println("Added");
			else
				System.out.println("Not Added");
	}catch(Exception e) {
		e.printStackTrace();
			
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	public int getFundTransferId() {
		int tid=0;
		java.sql.Statement st;
		try {
			Connection con=DBUtil.getConnection();
			String q="select fundTransferIdSeq.nextval from dual";
			st = con.createStatement();
			ResultSet rs=st.executeQuery(q);
			while(rs.next()) 
			   {
				  tid=rs.getInt(1);
				  return tid;
			   }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tid;
	}

	
}
