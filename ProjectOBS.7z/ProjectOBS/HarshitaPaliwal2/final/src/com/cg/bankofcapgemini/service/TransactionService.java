package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.dto.TransactionDetails;

public interface TransactionService  {
	public void insert(TransactionDetails t,int accNo);
	
}
