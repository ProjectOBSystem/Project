package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.dao.ChangePasswordDao;
import com.cg.bankofcapgemini.dao.ChangePasswordDaoImpl;
import com.cg.bankofcapgemini.exception.UserException;

public class ChangePasswordServiceImpl implements ChangePasswordService {
	
	ChangePasswordDao passwordDao = new ChangePasswordDaoImpl();
	
	@Override
	public boolean changepassword(String user_id, String curentpassword,
			String newpassword) throws UserException {
		// TODO Auto-generated method stub
		return passwordDao.changepassword(user_id, curentpassword, newpassword);
	}

	@Override
	public boolean passwordchange(String user_id, String newpassword)
			throws UserException {
		// TODO Auto-generated method stub
		return passwordDao.passwordchange(user_id, newpassword);
	}

}
