package com.cg.bankofcapgemini.dto;

public class User {
private int accNo;
private int userId;
private String loginPass;
private String secretQues;
private String TransPass;
private char lock;
public int getAccNo() {
	return accNo;
}
public void setAccNo(int accNo) {
	this.accNo = accNo;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public String getLoginPass() {
	return loginPass;
}
public void setLoginPass(String loginPass) {
	this.loginPass = loginPass;
}
public String getSecretQues() {
	return secretQues;
}
public void setSecretQues(String secretQues) {
	this.secretQues = secretQues;
}
public String getTransPass() {
	return TransPass;
}
public void setTransPass(String transPass) {
	TransPass = transPass;
}
public char getLock() {
	return lock;
}
public void setLock(char lock) {
	this.lock = lock;
}
@Override
public String toString() {
	return "User [accNo=" + accNo + ", userId=" + userId + ", loginPass="
			+ loginPass + ", secretQues=" + secretQues + ", TransPass="
			+ TransPass + ", lock=" + lock + "]";
}
public User(int accNo, int userId, String loginPass, String secretQues,
		String transPass, char lock) {
	super();
	this.accNo = accNo;
	this.userId = userId;
	this.loginPass = loginPass;
	this.secretQues = secretQues;
	TransPass = transPass;
	this.lock = lock;
}
public User() {
	// TODO Auto-generated constructor stub
}
}
