package com.cg.bankofcapgemini.dao;

import java.util.List;

import com.cg.bankofcapgemini.dto.AccountHolder;
import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.dto.User;
import com.cg.bankofcapgemini.exception.UserException;

public interface AdminDao {
	
	public User createaccount(AccountHolder account)throws UserException;
	public boolean checkadmin(String account,String password) throws UserException;
	public List<TransactionDetails> viewtransaction()throws UserException;
	public String getAdminName(String admin_id) throws UserException;
	
}
