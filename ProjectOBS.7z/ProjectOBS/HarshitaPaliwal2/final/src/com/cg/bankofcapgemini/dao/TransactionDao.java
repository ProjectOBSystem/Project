package com.cg.bankofcapgemini.dao;



import com.cg.bankofcapgemini.dto.TransactionDetails;



public interface TransactionDao  {
public void insert(TransactionDetails t,int accNo);
}
