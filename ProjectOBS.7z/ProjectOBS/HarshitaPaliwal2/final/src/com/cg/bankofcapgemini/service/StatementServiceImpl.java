package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dao.StatementDao;
import com.cg.bankofcapgemini.dao.StatementDaoImpl;
import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.exception.UserException;

public class StatementServiceImpl implements StatementService {

	StatementDao statementdao = new StatementDaoImpl();
	@Override
	public List<TransactionDetails> miniStatement(String user_id) throws UserException {
		// TODO Auto-generated method stub
		return statementdao.miniStatement(user_id);
	}

	@Override
	public List<TransactionDetails> detailStatement(String user_id) throws UserException {
		// TODO Auto-generated method stub
		return statementdao.detailStatement(user_id);
	}

}
