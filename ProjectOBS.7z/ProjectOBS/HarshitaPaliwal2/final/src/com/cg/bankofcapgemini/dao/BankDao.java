package com.cg.bankofcapgemini.dao;

import java.util.List;

import com.cg.bankofcapgemini.dto.Payee;




public interface BankDao {
public void add(Payee p);
public List<Payee> showAll(int accNo);
}
