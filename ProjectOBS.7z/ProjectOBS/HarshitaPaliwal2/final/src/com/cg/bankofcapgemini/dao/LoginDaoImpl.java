package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.cg.bankofcapgemini.exception.UserException;
import com.cg.bankofcapgemini.factory.DBUtil;

public class LoginDaoImpl implements LoginDao{

	@Override
	public boolean check_login(String user_id, String password) {

		boolean flag =false;

		try(Connection con = DBUtil.getConnection()){

			PreparedStatement ps = con.prepareStatement("Select * from UserTable where user_id=? and login_password=? and lock_status='N'");

			Integer userid = Integer.valueOf(user_id);

			ps.setInt(1, userid);

			ps.setString(2,password);

			ResultSet res= ps.executeQuery();

			if(res.next()==true){
				flag=true;
			
			}
			else{
				flag=false;
				
			}
		}catch (Exception e1){

			e1.printStackTrace();

		
		}	
		System.out.println("flag is: "+flag);
		return flag;
	}
	public void lock_counter(String account,int counter) throws UserException{
		
		try(Connection con = DBUtil.getConnection()){

			PreparedStatement ps = con.prepareStatement("update UserTable set counter=? where user_id=?");

			Integer userid = Integer.valueOf(account);
			ps.setInt(1,counter);
			ps.setInt(2, userid);
	
			ResultSet res= ps.executeQuery();

		}catch (Exception e1){

			e1.printStackTrace();

			throw new UserException(e1);
		}
	}
	public int lock_Status(String account) throws UserException{
		int counter=0;
		try(Connection con = DBUtil.getConnection()){

			PreparedStatement ps = con.prepareStatement("select * from usertable where user_id=?");

			Integer userid = Integer.valueOf(account);
		
			ps.setInt(1, userid);
	
			ResultSet res= ps.executeQuery();
			if(res.next()){
				counter=res.getInt("counter");
			}
		}catch (Exception e1){

			e1.printStackTrace();

			throw new UserException(e1);
		}
		return counter;
	}
	public void lock(String account) throws UserException{

		try(Connection con = DBUtil.getConnection()){

			PreparedStatement ps = con.prepareStatement("update UserTable set lock_status ='Y' where user_id=?");

			Integer userid = Integer.valueOf(account);

			ps.setInt(1, userid);

			ResultSet res= ps.executeQuery();

		}catch (Exception e1){

			e1.printStackTrace();

			throw new UserException(e1);
		}
	}
	public long forgotpassword(String user_id,String secret_answer) throws UserException{
		int code=0;

		try(Connection con = DBUtil.getConnection()){

			PreparedStatement ps = con.prepareStatement("Select * from UserTable where user_id=? and secret_question=? and lock_status='N' ");

			Integer userid = Integer.valueOf(user_id);

			ps.setInt(1, userid);
			ps.setString(2, secret_answer);

			ResultSet res= ps.executeQuery();

			if(res.next()){
				code = (int) (Math.random()*10000);
			}

		}catch (Exception e1){

			e1.printStackTrace();

			throw new UserException(e1);
		}
		return code;
	}

	public int getAccountId(String user_id) throws UserException{

		int account_id=0;

		try(Connection con = DBUtil.getConnection()){

			PreparedStatement ps = con.prepareStatement("select account_id from UserTable where user_id=? and lock_status='N'");

			Integer userid = Integer.valueOf(user_id);

			ps.setInt(1, userid);

			ResultSet res= ps.executeQuery();

			if(res.next()){
				account_id = res.getInt("account_id");
			}

		}catch (Exception e1){
			e1.printStackTrace();
		}
		return account_id;
	}

	public String getName(String user_id) throws UserException{

		String name="";

		int account_id = getAccountId(user_id);

		try(Connection con = DBUtil.getConnection()){

			PreparedStatement pstm = con.prepareStatement("Select customer_name from customer where account_id=?");

			pstm.setInt(1, account_id);

			ResultSet result= pstm.executeQuery();

			if(result.next()){

				name=result.getString("customer_name");

			}
		}catch (Exception e1){
			e1.printStackTrace();
		}

		return name;
	}
	@Override
	public double getBalance(String user_id) throws UserException {

		double balance =0;

		int accountid = getAccountId(user_id);

		try(Connection con = DBUtil.getConnection()){

			PreparedStatement pstm = con.prepareStatement("Select * from account_master where account_id=?");

			pstm.setInt(1, accountid);

			ResultSet res= pstm.executeQuery();

			if(res.next()){

				balance=res.getInt("account_balance");

			}
		}catch (Exception e1){
			e1.printStackTrace();
		}

		return balance;
	}

	public boolean validateuser(String user_id,long user_code,long system_code){

		boolean flag=false;

		try(Connection con = DBUtil.getConnection()){

			Integer userid = Integer.valueOf(user_id);

			PreparedStatement pstm = con.prepareStatement("Select * from UserTable where user_id=?");

			pstm.setInt(1, userid);

			ResultSet res= pstm.executeQuery();

			if(res.next()&&system_code==user_code)
			{
				flag =true;
			}
		}catch (Exception e1){
			e1.printStackTrace();	
		}
		return flag;
	}


}


