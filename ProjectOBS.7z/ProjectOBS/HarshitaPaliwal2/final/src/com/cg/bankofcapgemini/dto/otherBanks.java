package com.cg.bankofcapgemini.dto;


public class otherBanks {
	private int account_id;
	private String name;
	private String bank_name;
	private double balance;
	public otherBanks() {
		super();
		// TODO Auto-generated constructor stub
	}
	public otherBanks(int account_id, String name, 
			String bank_name, double balance) {
		super();
		this.account_id = account_id;
		this.name = name;
		this.bank_name = bank_name;
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "otherBanks [account_id=" + account_id + ", name=" + name
				+ ", lastName=" +  ", bank_name=" + bank_name
				+ ", balance=" + balance + "]";
	}
	
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	

}

