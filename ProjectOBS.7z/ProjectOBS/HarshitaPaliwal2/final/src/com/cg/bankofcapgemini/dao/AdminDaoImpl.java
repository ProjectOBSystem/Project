package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bankofcapgemini.dto.AccountHolder;
import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.dto.User;
import com.cg.bankofcapgemini.exception.UserException;
import com.cg.bankofcapgemini.factory.DBUtil;

public class AdminDaoImpl implements AdminDao {
	RequestCheckBookDao requestDao = new RequestChequeBookDaoImpl();
	
	LoginDao loginDao=new LoginDaoImpl();
	
public User createaccount(AccountHolder account){
	boolean flag= false;
	//loginDao.getAccountId(user_id);
	int id = accountid();
	 User user = new User();
	int userid=0;
	int random = (int) (Math.random()*100);
	
	String rand = String.valueOf(random);
	String pass="pass";
	try(Connection con = DBUtil.getConnection()){
		PreparedStatement pstm = con.prepareStatement("insert into customer values(?,?,?,?,?,?,?,?)");
		pstm.setInt(1,id);
		pstm.setString(2,account.getName());
		pstm.setString(3, account.getEmail());
		pstm.setString(4, account.getAddress());
		pstm.setString(6, account.getMobile());
		pstm.setString(7, account.getAccounttype());
		pstm.setDouble(8, account.getBalance());
		pstm.setString(5, account.getPancard());
		
		int status = pstm.executeUpdate();
		
		if(status==1){
			flag=true;
			//requestDao.updateServiceStatus(id);
		}
		 userid = getuserid(account,id);
		 PreparedStatement pst = con.prepareStatement("insert into account_master values(?,?,?,sysdate)");
			pst.setInt(1,id);
			pst.setString(2, account.getAccounttype());
			pst.setDouble(3, account.getBalance());
			
			
			 pst.executeUpdate();
			 insertServiceStatus(id,userid);
			
			 PreparedStatement ps = con.prepareStatement("select * from usertable where account_id=?");
				ps.setInt(1,id); 
				ResultSet res = ps.executeQuery();
				if(res.next()){
					user.setAccNo(res.getInt("account_id"));
					user.setUserId(res.getInt("user_id"));
					user.setTransPass(res.getString("Transaction_password"));
				}
				
	} catch (Exception e) {
		e.printStackTrace();
	}
	return user;
}
public int accountid(){
	int id = 0;
	try(Connection con = DBUtil.getConnection()){
		PreparedStatement pstm = con.prepareStatement("select accountid_seq.nextval from dual");
		
		ResultSet res = pstm.executeQuery();
		if(res.next()){
			id=res.getInt("nextval");
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	return id;
}
 public int getuserid(AccountHolder account,int accountid){
	 int userid = 0;
		
		int random = (int) (Math.random()*100);
		String rand = String.valueOf(random);
		String pass="pass";
		
		try(Connection con = DBUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement("select user_seq.nextval from dual");
			
			
			
			ResultSet res = pstm.executeQuery();
			if(res.next()){
				userid=res.getInt("nextval");
			}
			System.out.println("userdi id:"+userid);
			System.out.println("password log in isL:"+account.getPassword());
			PreparedStatement ps = con.prepareStatement("insert into usertable values(?,?,?,?,?,'N',0)");
			ps.setInt(1,accountid);
			ps.setInt(2, userid);
			ps.setString(3,account.getPassword());
			ps.setString(4,account.getPetname());
			ps.setString(5,pass+rand);
			
			ps.executeUpdate();
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userid;
 }
public boolean checkadmin(String account,String password) throws UserException{
	
	boolean flag =false;
	
	
	
	try(Connection con = DBUtil.getConnection()){
	
	PreparedStatement ps = con.prepareStatement("Select * from AdminTable where admin_id=? and password=?");

	Integer userid = Integer.valueOf(account);

	ps.setInt(1, userid);
	ps.setString(2,password);
	ResultSet res= ps.executeQuery();
	
	if(res.next()==true){
		flag=true;
	}
//	else{
//		flag=false;
//		throw new UserException("User not found");
//		
//	}
	}catch (Exception e1){
		
		e1.printStackTrace();
		
		throw new UserException(e1);
	}
	

	return flag;
	

	
}
public String getAdminName(String admin_id) throws UserException{
	String name="";
	
try(Connection con = DBUtil.getConnection()){
		
		Integer adminid = Integer.valueOf(admin_id);
		 PreparedStatement pstm = con.prepareStatement("Select name from AdminTable where admin_id=?");
		 pstm.setInt(1, adminid);
		
			ResultSet result= pstm.executeQuery();
			
			
			if(result.next()){
				System.out.println("heloo");
		 name=result.getString("name");
		 }
		}catch (Exception e1){
			
			e1.printStackTrace();
			
			
		}
	
	
	
	return name;
	
}
public List<TransactionDetails> viewtransaction(){
	
	List<TransactionDetails> myList = new ArrayList<TransactionDetails>();
	try(Connection con = DBUtil.getConnection()){
		
		 PreparedStatement pstm = con.prepareStatement("Select * from Transactions");
		 System.out.println("hello");
		ResultSet res= pstm.executeQuery();
		while(res.next()){
			TransactionDetails details = new TransactionDetails();
			details.setTransaction_Id(res.getLong("Transaction_ID"));	
			details.setTran_Description(res.getString("Tran_description"));
			details.setDateofTransaction(res.getDate("DateofTransaction"));
			details.setTransaction_Type(res.getString("TransactionType"));
			details.setTranAmount(res.getDouble("TranAmount"));
			details.setAccount_ID(res.getLong("Account_No"));
			
			myList.add(details);
			
		}

	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	
	return myList;
}
		
	
public void insertServiceStatus(int accountid,int userid) throws UserException{
	Long service_id = (long) (Math.random()*1000000);
	 
	
try(Connection con = DBUtil.getConnection()){
		
		System.out.println(accountid);
		 PreparedStatement pstm = con.prepareStatement("insert into service_tracker values(?,'CheckBookRequest',?,sysdate,'open',?)");
		 
		 pstm.setLong(1, service_id);
		 pstm.setInt(2,accountid);
		 pstm.setInt(3, userid);
			pstm.executeUpdate();
		}catch (Exception e1){
			
			e1.printStackTrace();
			
		}
	
	
}
}

