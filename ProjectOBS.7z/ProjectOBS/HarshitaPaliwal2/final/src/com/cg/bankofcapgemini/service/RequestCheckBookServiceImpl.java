package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dao.RequestCheckBookDao;
import com.cg.bankofcapgemini.dao.RequestChequeBookDaoImpl;
import com.cg.bankofcapgemini.dto.ServiceTracker;
import com.cg.bankofcapgemini.exception.UserException;

public class RequestCheckBookServiceImpl implements RequestCheckBookService {
	RequestCheckBookDao requestDao = new RequestChequeBookDaoImpl();

	@Override
	public  List<ServiceTracker> getServiceNumber(String userid)throws UserException {
	
		return requestDao.getServiceNumber(userid);
	}
	@Override
	public String getStatusOfSRN(int srn) throws UserException {
		
		return requestDao.getStatusOfSRN(srn);
	}
	
	@Override
	public List<ServiceTracker> getStatusOfAllRequest(Long account_id,String userid)
			throws UserException {
		
		return requestDao.getStatusOfAllRequest(account_id,userid);
	}
	@Override
	public List<ServiceTracker> getLatest20ServiceRequest(String userid)
			throws UserException {
		
		return requestDao.getLatest20ServiceRequest(userid);
	}
	@Override
	public long setServiceNumber(String user_id) throws UserException {
		// TODO Auto-generated method stub
		return requestDao.setServiceNumber(user_id);
	}

}
