package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.bankofcapgemini.exception.UserException;
import com.cg.bankofcapgemini.factory.DBUtil;

public class ChangePasswordDaoImpl implements ChangePasswordDao{

	public boolean changepassword(String user_id,String curentpassword,String newpassword) throws UserException{
		LoginDao loginDao = new LoginDaoImpl();
		boolean flag= false;

		boolean f = false;
		f= loginDao.check_login(user_id,curentpassword);

		if(f==true){
			try(Connection con = DBUtil.getConnection()){

				PreparedStatement pstm = con.prepareStatement("update UserTable set login_password  =? where login_password=?");
				Integer userid = Integer.valueOf(user_id);	
				pstm.setString(1,newpassword);
				pstm.setString(2,curentpassword);
				ResultSet res= pstm.executeQuery();
				if(res.next()==true){
					flag=true;
				}
				else{

				}
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			flag=false;
		}
		return flag; 

	}
	public boolean passwordchange(String user_id,String newpassword) throws UserException{
		boolean flag= false;

	


		try(Connection con = DBUtil.getConnection()){

			PreparedStatement pstm = con.prepareStatement("update UserTable set login_password  =? where user_id=?");
			Integer userid = Integer.valueOf(user_id);	
			System.out.println("userid is "+userid);
			System.out.println("new password is"+newpassword);
			pstm.setString(1,newpassword);
			pstm.setInt(2, userid);
			ResultSet res= pstm.executeQuery();
			if(res.next()==true){
				flag=true;
			}

		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("flag is: "+flag);
		return flag; 

	}
}
