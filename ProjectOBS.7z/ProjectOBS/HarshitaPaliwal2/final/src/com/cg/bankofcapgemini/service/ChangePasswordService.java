package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.exception.UserException;

public interface ChangePasswordService {
	
	public boolean changepassword(String user_id,String curentpassword,String newpassword)throws UserException;
	
	public boolean passwordchange(String user_id,String newpassword) throws UserException;
}