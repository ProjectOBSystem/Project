package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.exception.UserException;

public interface LoginService {
	public boolean check_login(String user_id,String password) throws UserException;
	
	public void lock(String user_id) throws UserException;
	
	public long forgotpassword(String user_id,String secret_answer) throws UserException;
	
	public double getBalance(String user_id)throws UserException;
	
	public String getName(String user_id) throws UserException;
	
	public boolean validateuser(String user_id,long user_code,long system_code);
	
	public int getAccountId(String user_id) throws UserException;
	
	public void lock_counter(String account,int counter) throws UserException;
	
	public int lock_Status(String account) throws UserException;
}
