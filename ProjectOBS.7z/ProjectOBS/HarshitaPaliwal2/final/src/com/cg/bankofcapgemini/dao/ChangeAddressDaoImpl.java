package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.bankofcapgemini.dto.Customer;
import com.cg.bankofcapgemini.exception.UserException;
import com.cg.bankofcapgemini.factory.DBUtil;

public class ChangeAddressDaoImpl implements ChangeAddressDao {
	
	LoginDao loginDao = new LoginDaoImpl();
	
	public Customer getAddressMobile(String user_id) throws UserException{
	
		Customer customer = new Customer();
		
		int account_id = loginDao.getAccountId(user_id);
		
		try(Connection con = DBUtil.getConnection()){

			PreparedStatement pstm = con.prepareStatement("Select * from customer where account_id=?");

			pstm.setInt(1, account_id);

			ResultSet result= pstm.executeQuery();

			if(result.next()){

				customer.setAddress(result.getString("address"));
		
				customer.setMobile(result.getString("mobile"));

			}
		}catch (Exception e1){
			e1.printStackTrace();
		}
		
		return customer;
	}
	public boolean changeAddress(String user_id, String address) throws UserException{
		
		boolean flag =false;
		
		int account_id = loginDao.getAccountId(user_id);
		
		try(Connection con = DBUtil.getConnection()){

			PreparedStatement pstm = con.prepareStatement("update customer set address=? where account_id=?");
			
			pstm.setString(1, address);
			
			pstm.setInt(2, account_id);

			ResultSet result= pstm.executeQuery();

			if(result.next()){		
					flag=true;
			}
		}catch (Exception e1){
			e1.printStackTrace();
		}
		return flag;
		
	}
public boolean changeMobile(String user_id, String mobile) throws UserException{
		
		boolean flag =false;
		
		int account_id = loginDao.getAccountId(user_id);
		
		try(Connection con = DBUtil.getConnection()){

			PreparedStatement pstm = con.prepareStatement("update customer set mobile=? where account_id=?");
			
			pstm.setString(1, mobile);
			
			pstm.setInt(2, account_id);

			ResultSet result= pstm.executeQuery();

			if(result.next()){		
					flag=true;
			}
		}catch (Exception e1){
			e1.printStackTrace();
		}
		return flag;
		
	}
}
