package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dto.Payee;

public interface PayeeService {
	public void add(Payee p);
	public List<Payee> showAll(int accNo);
}
