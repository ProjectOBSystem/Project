package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dao.UserDao;
import com.cg.bankofcapgemini.dao.UserDaoImpl;
import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.dto.User;
import com.cg.bankofcapgemini.dto.otherBanks;

public class UserServImpl implements UserServ {
UserDao udao=new UserDaoImpl();
	@Override
	public String getTransPass(User u) {
		// TODO Auto-generated method stub
		return udao.getTransPass(u);
	}
	@Override
	public boolean UpdateUserAccount(int accNo,int amm) {
		return udao.UpdateUserAccount(accNo, amm);
		
	}
	
	@Override
	public List<otherBanks> getAllBanks(String name) {
		// TODO Auto-generated method stub
		return udao.getAllBanks(name);
	}
	@Override
	public boolean checkAccountNum(int accNum) {
		return udao.checkAccountNum(accNum);
	}
	@Override
	public boolean UpdatePayeeAccount(int accNo, int amm,TransactionDetails transaction) {
	return udao.UpdatePayeeAccount(accNo, amm,transaction);
		
	}
	

	
}
