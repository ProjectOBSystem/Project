package com.cg.bankofcapgemini.dto;

public class FundTransfer {
	private int FundTransfer_ID;
	private int Account_ID ;
	private int Payee_Account_ID;
	private String Date_Of_Transfer;
	private float Transfer_Amount;
	public int getFundTransfer_ID() {
		return FundTransfer_ID;
	}
	public void setFundTransfer_ID(int fundTransfer_ID) {
		FundTransfer_ID = fundTransfer_ID;
	}
	public int getAccount_ID() {
		return Account_ID;
	}
	public void setAccount_ID(int account_ID) {
		Account_ID = account_ID;
	}
	public int getPayee_Account_ID() {
		return Payee_Account_ID;
	}
	public void setPayee_Account_ID(int payee_Account_ID) {
		Payee_Account_ID = payee_Account_ID;
	}
	public String getDate_Of_Transfer() {
		return Date_Of_Transfer;
	}
	public void setDate_Of_Transfer(String date_Of_Transfer) {
		Date_Of_Transfer = date_Of_Transfer;
	}
	public float getTransfer_Amount() {
		return Transfer_Amount;
	}
	public void setTransfer_Amount(float transfer_Amount) {
		Transfer_Amount = transfer_Amount;
	}
	public FundTransfer(int fundTransfer_ID, int account_ID,
			int payee_Account_ID, String date_Of_Transfer, float transfer_Amount) {
		super();
		FundTransfer_ID = fundTransfer_ID;
		Account_ID = account_ID;
		Payee_Account_ID = payee_Account_ID;
		Date_Of_Transfer = date_Of_Transfer;
		Transfer_Amount = transfer_Amount;
	}
	public FundTransfer() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "FundTransfer [FundTransfer_ID=" + FundTransfer_ID
				+ ", Account_ID=" + Account_ID + ", Payee_Account_ID="
				+ Payee_Account_ID + ", Date_Of_Transfer=" + Date_Of_Transfer
				+ ", Transfer_Amount=" + Transfer_Amount + "]";
	}
}
