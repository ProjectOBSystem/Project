package com.cg.bankofcapgemini.dto;

import java.util.Date;

public class ServiceTracker {
private long service_id;
private String service_description;
private int accountid;
private String service_request;
private String service_status;
private Date service_raised_date;

public Date getService_raised_date() {
	return service_raised_date;
}
public void setService_raised_date(Date service_raised_date) {
	this.service_raised_date = service_raised_date;
}
public long getService_id() {
	return service_id;
}
public void setService_id(long service_id) {
	this.service_id = service_id;
}
public String getService_description() {
	return service_description;
}
public void setService_description(String service_description) {
	this.service_description = service_description;
}
public int getAccountid() {
	return accountid;
}
public void setAccountid(int accountid) {
	this.accountid = accountid;
}
public String getService_request() {
	return service_request;
}
public void setService_request(String service_request) {
	this.service_request = service_request;
}
public String getService_status() {
	return service_status;
}
public void setService_status(String service_status) {
	this.service_status = service_status;
}
public ServiceTracker(long service_id, String service_description, int accountid, String service_request,
		String service_status) {
	super();
	this.service_id = service_id;
	this.service_description = service_description;
	this.accountid = accountid;
	this.service_request = service_request;
	this.service_status = service_status;
}
public ServiceTracker() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "ServiceTracker [service_id=" + service_id
			+ ", service_description=" + service_description + ", accountid="
			+ accountid + ", service_request=" + service_request
			+ ", service_status=" + service_status + ", service_raised_date="
			+ service_raised_date + "]";
}

}
