package com.cg.bankofcapgemini.dto;

public class Payee {
private int accNo;
private int payeeAccNo;
private String name;
public int getAccNo() {
	return accNo;
}
public void setAccNo(int accNo) {
	this.accNo = accNo;
}
public int getPayeeAccNo() {
	return payeeAccNo;
}
public void setPayeeAccNo(int payeeAccNo) {
	this.payeeAccNo = payeeAccNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return "Payee [accNo=" + accNo + ", payeeAccNo=" + payeeAccNo + ", name="
			+ name + "]";
}
public Payee(int accNo, int payeeAccNo, String name) {
	super();
	this.accNo = accNo;
	this.payeeAccNo = payeeAccNo;
	this.name = name;
}
public Payee() {
	// TODO Auto-generated constructor stub
}
}
