package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.dto.Customer;
import com.cg.bankofcapgemini.exception.UserException;

public interface ChangeAddressService {
	
	public Customer getAddressMobile(String user_id) throws UserException;
	
	public boolean changeAddress(String user_id, String address) throws UserException;
	
	public boolean changeMobile(String user_id, String mobile) throws UserException;
}
