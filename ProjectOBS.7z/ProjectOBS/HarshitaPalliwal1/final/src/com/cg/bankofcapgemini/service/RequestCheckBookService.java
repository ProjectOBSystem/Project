package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dto.ServiceTracker;
import com.cg.bankofcapgemini.exception.UserException;

public interface RequestCheckBookService {
	public  List<ServiceTracker> getServiceNumber(String user_id)throws UserException;
	public String getStatusOfSRN(int srn)throws UserException;
	public List<ServiceTracker> getStatusOfAllRequest(Long account_id,String user_id)throws UserException;
	public List<ServiceTracker> getLatest20ServiceRequest(String user_id)throws UserException;
	public long setServiceNumber(String user_id) throws UserException;
	
}
