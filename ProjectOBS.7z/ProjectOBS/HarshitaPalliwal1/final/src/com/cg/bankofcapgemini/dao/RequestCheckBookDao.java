package com.cg.bankofcapgemini.dao;

import java.util.List;

import com.cg.bankofcapgemini.dto.ServiceTracker;
import com.cg.bankofcapgemini.exception.UserException;

public interface RequestCheckBookDao {

	public List<ServiceTracker> getLatest20ServiceRequest(String userid)throws UserException ;
	public List<ServiceTracker> getStatusOfAllRequest(Long accountid,String userid)
			throws UserException;
	public String getStatusOfSRN(int srn) throws UserException;
	public List<ServiceTracker> getServiceNumber(String userid)throws UserException;
	public Long setServiceNumber(String user_id) throws UserException;
	public void updateServiceStatus(int accountid) throws UserException;
}
