package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.bankofcapgemini.dto.TransactionDetails;

import com.cg.bankofcapgemini.factory.DBUtil;

public class StatementDaoImpl implements StatementDao {
	
	LoginDao loginDao = new LoginDaoImpl();
	
	public List<TransactionDetails> miniStatement(String userid){

		List<TransactionDetails> myList = new ArrayList<TransactionDetails>();
		
		try(Connection con = DBUtil.getConnection()){
		
			int accountid = loginDao.getAccountId(userid);
			
			PreparedStatement pstm = con.prepareStatement(" Select * from Transactions where Account_No = ? and rownum<=10");
			
			pstm.setInt(1, accountid);
			
			ResultSet res= pstm.executeQuery();
			
			while(res.next()){
			
				TransactionDetails details = new TransactionDetails();
				
				details.setTransaction_Id(res.getLong("Transaction_ID"));	
				
				details.setTran_Description(res.getString("Tran_description"));
				
				details.setDateofTransaction(res.getDate("DateofTransaction"));
				
				details.setTransaction_Type(res.getString("TransactionType"));
				
				details.setTranAmount(res.getDouble("TranAmount"));
				
				details.setAccount_ID(res.getLong("Account_No"));
				
				myList.add(details);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return myList;
	}
	public List<TransactionDetails> detailStatement(String userid){

		List<TransactionDetails> myList = new ArrayList<TransactionDetails>();
		
		try(Connection con = DBUtil.getConnection()){
		
			int accountid = loginDao.getAccountId(userid);
			
			PreparedStatement pstm = con.prepareStatement(" Select * from Transactions where Account_No = ?");
			
			pstm.setInt(1, accountid);
			
			ResultSet res= pstm.executeQuery();
			
			while(res.next()){
			
				TransactionDetails details = new TransactionDetails();
				
				details.setTransaction_Id(res.getLong("Transaction_ID"));	
				
				details.setTran_Description(res.getString("Tran_description"));
				
				details.setDateofTransaction(res.getDate("DateofTransaction"));
				
				details.setTransaction_Type(res.getString("TransactionType"));
				
				details.setTranAmount(res.getDouble("TranAmount"));
				
				details.setAccount_ID(res.getLong("Account_No"));
				
				myList.add(details);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return myList;
	}


}
