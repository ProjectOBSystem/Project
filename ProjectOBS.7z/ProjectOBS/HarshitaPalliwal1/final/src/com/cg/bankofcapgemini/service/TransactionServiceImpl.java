package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.dao.TransactionDao;
import com.cg.bankofcapgemini.dao.TransactionDaoImpl;
import com.cg.bankofcapgemini.dto.TransactionDetails;

public class TransactionServiceImpl implements TransactionService {
TransactionDao tdao=new TransactionDaoImpl();
	@Override
	public void insert(TransactionDetails t,int accNo) {
		tdao.insert(t,accNo);
		
	}

}
