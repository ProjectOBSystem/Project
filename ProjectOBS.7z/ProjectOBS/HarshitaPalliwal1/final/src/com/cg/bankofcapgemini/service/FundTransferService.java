package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.dto.FundTransfer;



public interface FundTransferService {
	public void insert(FundTransfer ft );
}
