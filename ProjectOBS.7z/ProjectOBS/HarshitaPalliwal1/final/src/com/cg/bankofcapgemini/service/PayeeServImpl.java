package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dao.BankDao;
import com.cg.bankofcapgemini.dao.BankDaoImpl;
import com.cg.bankofcapgemini.dto.Payee;

public class PayeeServImpl implements PayeeService {
BankDao bdao=new BankDaoImpl();
	@Override
	public void add(Payee p) {
		// TODO Auto-generated method stub
		bdao.add(p);

	}

	@Override
	public List<Payee> showAll(int accNo) {
		// TODO Auto-generated method stub
		return bdao.showAll(accNo);
	}

}
