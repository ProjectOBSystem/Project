package com.cg.bankofcapgemini.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.Transaction;

import com.cg.bankofcapgemini.dto.AccountHolder;
import com.cg.bankofcapgemini.dto.Customer;
import com.cg.bankofcapgemini.dto.FundTransfer;
import com.cg.bankofcapgemini.dto.Payee;
import com.cg.bankofcapgemini.dto.ServiceTracker;
import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.dto.User;
import com.cg.bankofcapgemini.dto.otherBanks;
import com.cg.bankofcapgemini.exception.UserException;
import com.cg.bankofcapgemini.service.AdminService;
import com.cg.bankofcapgemini.service.AdminServiceImpl;
import com.cg.bankofcapgemini.service.ChangeAddressService;
import com.cg.bankofcapgemini.service.ChangeAddressServiceImpl;
import com.cg.bankofcapgemini.service.ChangePasswordService;
import com.cg.bankofcapgemini.service.ChangePasswordServiceImpl;
import com.cg.bankofcapgemini.service.FundTransferService;
import com.cg.bankofcapgemini.service.FundTransferServiceImpl;
import com.cg.bankofcapgemini.service.LoginService;
import com.cg.bankofcapgemini.service.LoginServiceImpl;
import com.cg.bankofcapgemini.service.PayeeServImpl;
import com.cg.bankofcapgemini.service.PayeeService;
import com.cg.bankofcapgemini.service.RequestCheckBookService;
import com.cg.bankofcapgemini.service.RequestCheckBookServiceImpl;
import com.cg.bankofcapgemini.service.StatementService;
import com.cg.bankofcapgemini.service.StatementServiceImpl;
import com.cg.bankofcapgemini.service.TransactionService;
import com.cg.bankofcapgemini.service.TransactionServiceImpl;
import com.cg.bankofcapgemini.service.UserServ;
import com.cg.bankofcapgemini.service.UserServImpl;

/**
 * Servlet implementation class Check
 */
@WebServlet("/Check")
public class Check extends HttpServlet {
	private static LoginService loginService;
	private static StatementService statementService;
	private static ChangeAddressService addressService;
	private static ChangePasswordService passwordService;
	private static AdminService adminService;
	private static RequestCheckBookService checkbookService;
	PayeeService pserv=new PayeeServImpl();
	UserServ userv=new UserServImpl();
	TransactionService tserv=new TransactionServiceImpl();
	FundTransferService fserv=new  FundTransferServiceImpl();
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	int counter =0;
	public Check() {
		loginService = new LoginServiceImpl();
		
		statementService = new StatementServiceImpl();
		
		addressService = new ChangeAddressServiceImpl();
		
		passwordService = new ChangePasswordServiceImpl();
		
		adminService = new AdminServiceImpl();
		
		checkbookService = new RequestCheckBookServiceImpl();
		
		pserv=new PayeeServImpl();
		userv=new UserServImpl();
		tserv=new TransactionServiceImpl();
		fserv=new  FundTransferServiceImpl();
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processrequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processrequest(request,response);
	}
	protected void processrequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String desc=null;
		Payee p=new Payee();
		ServletContext context=getServletContext();

		HttpSession usersession = request.getSession(false);

		if(usersession == null){
			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");

			request.setAttribute("errorMessage", "you need to Log in to access this page<a href = 'Login.jsp'>Click Here </a>to Login");

			rd.forward(request, response);	

			return;
		}

		String action = request.getParameter("action");

		switch(action){

		case "Login":{
			String name="";
			double balance=0;

			boolean flag =false;
			int accountid = 0;
			

			String user_id = request.getParameter("user_id");

			String password = request.getParameter("password");

			try {
				flag=loginService.check_login(user_id, password);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("flag is "+flag);
			if(flag ==true) {
				HttpSession session = request.getSession(true);
				session.setAttribute("user_id", user_id);
				try {
					accountid = loginService.getAccountId(user_id);
					balance= loginService.getBalance(user_id);
					name= loginService.getName(user_id);
					System.out.println("nsme id: "+name);
					System.out.println("balance is:"+balance);
					System.out.println("accountid is:"+accountid);
					counter=0;
					loginService.lock_counter(user_id, counter);
				} catch (UserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				session.setAttribute("balance", balance);

				session.setAttribute("name", name);
				request.setAttribute("acountid", accountid);
				session.setAttribute("acountid", accountid);
				RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
			}
			else {
				counter++;
				try {
					loginService.lock_counter(user_id, counter);
				} catch (UserException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println("counter is: "+counter);
				try {
					counter=loginService.lock_Status(user_id);
				} catch (UserException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(counter==3){
					try {
						System.out.println("counter is: "+counter);
						loginService.lock(user_id);
						RequestDispatcher rd = request.getRequestDispatcher("lockError.jsp");
						rd.forward(request, response);

					} catch (UserException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			RequestDispatcher rd = request.getRequestDispatcher("loginError.jsp");
				rd.forward(request, response);
				
		}
		}
		break;
		case "forgotpassword":
		{	
			long system_code=0;
			boolean flag=false;
			String user_id= request.getParameter("user_id");
			String secret_answer = request.getParameter("secret_answer");

			context.setAttribute("user_id",user_id);
			context.setAttribute("secret_answer",secret_answer);
			try {
				system_code = loginService.forgotpassword(user_id, secret_answer);
				if(system_code==0){
					flag=true;
				}
				context.setAttribute("system_code", system_code);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			HttpSession session = request.getSession();
			session.setAttribute("system_code", system_code);
			if(flag==false){
				RequestDispatcher rd = request.getRequestDispatcher("forgotPassword.jsp");
				rd.forward(request, response);
			}
			else{

				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);
			}
		}
		break;

		case "forgotlink":
		{

			String name="";
			double balance=0;
			boolean f =false;

			String user_id =request.getParameter("user_id");

			long system_code =(long) context.getAttribute("system_code");

			String user_code =request.getParameter("user_code");


			try{
			Integer code = Integer.valueOf(user_code);
			long usercode = code.longValue();
			f = loginService.validateuser(user_id, usercode, system_code);
			}catch(NumberFormatException e){
				request.setAttribute("errorMessage", e.getMessage());
				request.getRequestDispatcher("error.jsp").forward(request, response);;
			
			}
			
			
			
			System.out.println("flag is:"+f);
			if(f ==true) {
		try{
				HttpSession session = request.getSession(true);
				session.setAttribute("user_id", user_id);
				
					balance= loginService.getBalance(user_id);
					name= loginService.getName(user_id);
					session.setAttribute("name", name);
					session.setAttribute("balance", balance);
					RequestDispatcher rd = request.getRequestDispatcher("Passwordchangeforforgotpassword.jsp");
					rd.forward(request, response);
				} 
			
			
			catch (UserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

					request.setAttribute("errorMessage", e.getMessage());
					request.getRequestDispatcher("error.jsp").forward(request, response);;
				}}
		else{


			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
			rd.forward(request, response);
		}
				
			}
			
		
		break;
		case "ministatement":
		{
			HttpSession session = request.getSession();

			String user_id = (String) session.getAttribute("user_id");

			List<TransactionDetails> details;

			try {
				details = statementService.miniStatement(user_id);

				request.setAttribute("details", details);

				request.getRequestDispatcher("miniStatement.jsp").forward(request, response);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		break;
		case "detailstatement":
		{
			HttpSession session = request.getSession();

			String user_id = (String) session.getAttribute("user_id");

			List<TransactionDetails> details;

			try {
				details = statementService.detailStatement(user_id);

				request.setAttribute("details", details);

				request.getRequestDispatcher("detailStatement.jsp").forward(request, response);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		break;
		case "changepassword":
		{
			boolean flag =false;
			HttpSession session = request.getSession();
			
			String userid = (String) session.getAttribute("user_id");
			String currentpassword= request.getParameter("currentpassword");
			String newpassword = request.getParameter("newpassword");
			
		
			try {
				flag = passwordService.changepassword(userid, currentpassword, newpassword);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(flag==true){
				request.getRequestDispatcher("PasswordChangeSuccess.jsp").forward(request, response);
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);	
			}
			
		}
		break;
		
		case "passwordchange":
		{
			boolean flag =false;
			
			
			String user_id =  request.getParameter("user_id");
		
			String newpassword = request.getParameter("newpassword");
			
			
			try {
				flag = passwordService.passwordchange(user_id, newpassword);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(flag==true){
				request.getRequestDispatcher("PasswordChangeSuccess.jsp").forward(request, response);
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);	
			}
			
		}
		break;
		
		case"displayAddressMobile":
		{
			HttpSession session = request.getSession();

			String user_id = (String) session.getAttribute("user_id");
			
			Customer customer = new Customer();
			
			try {
				
				customer = addressService.getAddressMobile(user_id);
				
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			String address = customer.getAddress();
			
			String mobile = customer.getMobile();
			
			session.setAttribute("address", address);
			
			session.setAttribute("mobile", mobile);
			
			request.getRequestDispatcher("requestChangeAddress.jsp").forward(request, response);
		
		}
		break;
		
		case "changeAddress":
		{
			boolean flag =false;
			HttpSession session = request.getSession();

			String user_id = (String) session.getAttribute("user_id");
			
			String address = request.getParameter("address");
			
			try {
				flag = addressService.changeAddress(user_id, address);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(flag==true){
				request.getRequestDispatcher("addressChangeSuccess.jsp").forward(request, response);
				
			}
			
		}
		break;
		
		case "changeMobile":
		{
			boolean flag =false;
			HttpSession session = request.getSession();

			String user_id = (String) session.getAttribute("user_id");
			
			String mobile = request.getParameter("mobile");
			
			try {
				flag = addressService.changeMobile(user_id, mobile);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(flag==true){
				request.getRequestDispatcher("mobileChangeSuccess.jsp").forward(request, response);
				
			}
			
		}
		break;
		case "adminLogin":
		{
			boolean flag =false;
			String name="";
			String userid = request.getParameter("userid");
			String password = request.getParameter("password");
			try {
				flag=adminService.checkadmin(userid, password);
				name = adminService.getAdminName(userid);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(flag ==true) {
				HttpSession session = request.getSession(true);
				session.setAttribute("adminid", userid);
				session.setAttribute("admin_name", name);
				
				 
				
				RequestDispatcher rd = request.getRequestDispatcher("adminSelections.jsp");
				rd.forward(request, response);
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("loginError.jsp");
				rd.forward(request, response);	
			}
		}
		break;
		case "createaccount":
		{
			int userid=0;
			boolean flag=false;
			String name = request.getParameter("name");
			String address = request.getParameter("address");
			String email = request.getParameter("email");
			String mobile = request.getParameter("mobile");
			String accounttype= request.getParameter("accounttype");
			String balance = request.getParameter("balance");
			String pancard = request.getParameter("pancard");
			String password= request.getParameter("password");
			String petname=request.getParameter("petname");
			double account_balance = Double.valueOf(balance);
			
			AccountHolder account = new AccountHolder();
			account.setName(name);
			account.setAddress(address);
			account.setEmail(email);
			account.setMobile(mobile);
			account.setAccounttype(accounttype);
			account.setBalance(account_balance);
			account.setPancard(pancard);
			account.setPassword(password);
			account.setPetname(petname);
			System.out.println("new account details: "+account.toString());
			System.out.println("password log in isL:"+password);
			try {
				flag=adminService.createaccount(account);
				userid = adminService.getuserid();
				
				
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(flag==true){
			RequestDispatcher rd = request.getRequestDispatcher("AccountCreated.jsp");
			System.out.println("id id"+userid);
			request.setAttribute("userid", userid);;
			rd.forward(request, response);	
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);	
			}
		}
		break;
		case "viewtransactions":
		{
			List<TransactionDetails> details;
			
			try {
				details = adminService.viewtransaction();

				request.setAttribute("details", details);
				
				request.getRequestDispatcher("viewtransactions.jsp").forward(request, response);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		break;
		
		case "requestCheckbook":
		{
			long service_id = 0;
			HttpSession session = request.getSession();
			
			String user_id = (String) session.getAttribute("user_id");
			
			try {
				
				service_id = checkbookService.setServiceNumber(user_id);
				
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			if(service_id!=0l){
			request.setAttribute("service_id",service_id);
			
			request.getRequestDispatcher("requestChequeBook.jsp").forward(request, response);
			}
			else{
				request.getRequestDispatcher("chequeBookIssued.jsp").forward(request, response);
			}
				
			
		}
		break;
		case"requestnumber":
			
		{
			HttpSession session = request.getSession();
			
			String user_id = (String) session.getAttribute("user_id");
			
			
			try {
			
				 List<ServiceTracker> myList=checkbookService.getServiceNumber(user_id);
				request.setAttribute("myList", myList);
				System.out.println("list is: "+myList);
				request.getRequestDispatcher("serviceRequestNumbers.jsp").forward(request, response);
			} catch (UserException e) {
				e.printStackTrace();
			}
		}
		
		break;
		
		case"statusOfRequest":
			
		{
			String status;
			String serviceRequestNo=request.getParameter("SRN");
			
			
		
			
		
			try {
				Integer srn = Integer.valueOf(serviceRequestNo);
				status=checkbookService.getStatusOfSRN(srn);
			
								request.setAttribute("status", status);
								
								request.getRequestDispatcher("statusOfServiceRequestNo.jsp").forward(request, response);
							} catch (NumberFormatException|UserException e) {
								e.printStackTrace();
								request.setAttribute("errorMessage", e.getMessage());
								
								request.getRequestDispatcher("errorRequest.jsp").forward(request, response);;
							}
		}
		
		case"statusOfAllRequest":{
HttpSession session = request.getSession();
			
			String user_id = (String) session.getAttribute("user_id");
			String account_id = request.getParameter("accountid");
			
try {
	Long accountid = Long.valueOf(account_id);
				List<ServiceTracker> allStatusList=checkbookService.getStatusOfAllRequest(accountid,user_id);
				
								request.setAttribute("allStatusList", allStatusList);
								
								request.getRequestDispatcher("allStatus.jsp").forward(request, response);
							} catch (NumberFormatException|UserException e) {
								e.printStackTrace();
	request.setAttribute("errorMessage", e.getMessage());
								
								request.getRequestDispatcher("errorRequest.jsp").forward(request, response);;
							}
		}
		break;
		case"latest20ServiceRequest":{
HttpSession session = request.getSession();
			
			String user_id = (String) session.getAttribute("user_id");
			
try {
				
				List<ServiceTracker> latest20SRN=checkbookService.getLatest20ServiceRequest(user_id);
				System.out.println("List of request is: " +latest20SRN);
								request.setAttribute("latest20SRN", latest20SRN);
								
								request.getRequestDispatcher("last20ServiceRequest.jsp").forward(request, response);
							} catch (UserException e) {
								e.printStackTrace();
							}
		}
			

break;



		case "otp":
		{
			try {
				HttpSession session=request.getSession();
				
			
				String name=request.getParameter("name");
				String accNo=request.getParameter("accountNumber");
				if(userv.checkAccountNum(Integer.parseInt(accNo))) {
					RequestDispatcher rd=request.getRequestDispatcher("otp.jsp");
					session.setAttribute("payeename",name);
					session.setAttribute("accNo",accNo);
					rd.forward(request, response);
				}
				else {
					RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
					request.setAttribute("message","Invalid Account number");
					rd.forward(request, response);
				}
				//session.setAttribute("p",p);

				
			} catch (ServletException|IOException e) {
				e.printStackTrace();
			}
			break;
		}
		
		//DISPLAYING DROP DOWN LIST OF PAYEES FROM PAYEE TABLE after INDEX PAGE
				case "payeeList":
				{
					int an=0;
					String name=null;
					desc="Across Same bank";
					try {
						HttpSession session=request.getSession(true);
						session.setAttribute("desc",desc);
						RequestDispatcher rd=request.getRequestDispatcher("makeTransfer.jsp");
						String user_id = (String) session.getAttribute("user_id");
						int account_id = loginService.getAccountId(user_id);
						List<Payee> l=pserv.showAll(account_id);
						System.out.println(l);
						request.setAttribute("l", pserv.showAll(account_id));
						for(Payee p2:l)
							{
								an=p2.getAccNo();
								name=p2.getName();
							}
						request.setAttribute("accountNum",an);
						request.setAttribute("name",name);
						rd.forward(request, response);
					} catch (ServletException | IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (UserException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					break;
				}
				
				
				case "addPayee":
				{
					try {
						HttpSession session=request.getSession(false);
						System.out.println("******************in addPaye**************");
						RequestDispatcher rd=request.getRequestDispatcher("addPayee.jsp");
						rd.forward(request, response);
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				}
				
				

				//THIS METHOD ADDS A PAYEE TO PAYEE TABLE
				case "Add":
				{
					try {
						HttpSession session=request.getSession(false);
						System.out.println("*****************In add**************");
						String otp=request.getParameter("otp");//GETS OTP FROM JSP
						if(otp.equals("12345")) {
							String name=(String) session.getAttribute("payeename");
							String accNo=(String) session.getAttribute("accNo");
							String user_id = (String) session.getAttribute("user_id");
							int account_id = loginService.getAccountId(user_id);
							p.setAccNo(account_id);
							p.setPayeeAccNo(Integer.parseInt(accNo));
							p.setName(name);
							pserv.add(p);//ADD INTO PAYEETABLE
							RequestDispatcher rd=request.getRequestDispatcher("Check?action=payeeList");
							rd.forward(request, response);
							System.out.println("Addded");
						}
						else 
							{
							RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
							request.setAttribute("message","Invalid URN");
							rd.forward(request, response);
							}
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				}



				case "pay":
				{
					boolean flag=false;
					HttpSession session=request.getSession();
					System.out.println("**************Pay**************");
					try {
					int ammnt=Integer.parseInt(request.getParameter("ammount"));//GET AMMOUNT TO BE TRANSFERED
					String pass=request.getParameter("password");//GETS TRANSACTION PASSWORD
					String AccNo=(String) session.getAttribute("accountNum");//GETS ACCOUNT NUMBER OF PAYYE FROM SESSION
					System.out.println("In pay"+AccNo);
					User u=new User();

					FundTransfer ft=new FundTransfer();
					String transactionDesc=(String) session.getAttribute("desc");
					//SET TRANSACTION DETAILS FOR INSERTION IN TRANSACTION TABLE
					TransactionDetails t=new TransactionDetails();
					TransactionDetails transactionPayee=new TransactionDetails();
					String user_id = (String) session.getAttribute("user_id");
					int accountid;
					
						accountid = loginService.getAccountId(user_id);
						t.setAccount_ID(accountid);//From session
						t.setTranAmount(ammnt);
						t.setTran_Description(transactionDesc);
						
						
						//SET FUND TRANSFER DETAILS FOR INSERTION IN FUND TRANSFER DETAILS
						ft.setAccount_ID(accountid);
						System.out.println("Acc no is"+AccNo);
						ft.setPayee_Account_ID(accountid);
						ft.setTransfer_Amount(ammnt);
						u.setAccNo(accountid);//PROVIDE ACCNO TO CHECK PASSWORD GET THIS FROM SESSION
						String transpass=userv.getTransPass(u);//GET TRANSACTION PASSWORD ON THE BASIS OF ACCOUNT NUM
						if(pass.equals(transpass)){
							flag=userv.UpdateUserAccount(accountid,ammnt);//UPDATE USER ACCOUNT
							
						if(flag==false) {
							if(transactionDesc.equals("Across Same bank")) {
								System.out.println("INside if");
								transactionPayee.setAccount_ID(Integer.parseInt(AccNo));
								transactionPayee.setTranAmount(ammnt);
								transactionPayee.setTran_Description(transactionDesc);
								userv.UpdatePayeeAccount(Integer.parseInt(AccNo), ammnt,transactionPayee);
							}
							
							
							tserv.insert(t,accountid);//INSERT INTO TRANSACTION
							fserv.insert(ft);//INSERT INTO FUND TRANSFER TABLE
							RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
							rd.forward(request, response);
							
						}
						else {
							RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
							//	request.setAttribute("message","insufficient balance");
								rd.forward(request, response);
						}
							
						}
						else {
							RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
							request.setAttribute("message","Invalid Transaction Password");
							rd.forward(request, response);
							
						}
				
					} catch (NumberFormatException|UserException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
						request.setAttribute("message","Invalid Transaction Password");
						rd.forward(request, response);
					}
					break;
				}
		
				case "pay2":
				{
					try {
							HttpSession session=request.getSession();
							System.out.println("executing now");
							String AccNo=request.getParameter("payee");
							RequestDispatcher rd=request.getRequestDispatcher("pay.jsp");
							session.setAttribute("accountNum",AccNo);
							rd.forward(request, response);	
						}
					catch (NumberFormatException e) {
						e.printStackTrace();
						RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
						request.setAttribute("message","Invalid Transaction Password");
						rd.forward(request, response);
					}
					break;
						
					} 
				
				//FOR LINK 1 DIFFERENT BANK ACCOUNT
				case "myAccountAnotherBank":{

					/*String userid = (String) session.getAttribute("account");
					

					String serviceId = (String) session.getAttribute("serviceId");*/
					HttpSession session=request.getSession();
					String name = (String) session.getAttribute("name");
					System.out.println("session name is: "+name);
					desc="Across India";
					List<otherBanks> details;
					System.out.println("In controller ");
					try {

						details = userv.getAllBanks(name);
						// System.out.println(serviceId);
						System.out.println(details);
						RequestDispatcher rd=request.getRequestDispatcher("otherbank.jsp");
						session.setAttribute("desc",desc);
						request.setAttribute("details", details);
						rd.forward(request, response);

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				}
				






		case "Logout":
		{
			HttpSession session = request.getSession(false);
			if(session!=null){
				session.invalidate();
			}
			RequestDispatcher rd = request.getRequestDispatcher("greetings.jsp");
			rd.forward(request, response);
			break;
		}

		default:
		{
			RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
			request.setAttribute("errorMessage", "the page you does not exist");
			rd.forward(request, response);	
			break;
		}
		


		}

	}
}
