package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.bankofcapgemini.dto.Payee;
import com.cg.bankofcapgemini.factory.DBUtil;


public class BankDaoImpl implements BankDao{
	private LoginDao logindao=new LoginDaoImpl();
	@Override
	public void add(Payee p) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con=DBUtil.getConnection();
			String q="insert into payee values(?,?,?)";
			PreparedStatement pt=con.prepareStatement(q);
			pt.setInt(1,p.getAccNo());
			pt.setInt(2,p.getPayeeAccNo());
			pt.setString(3,p.getName());
			int i=pt.executeUpdate();
			if(i==1)
				System.out.println("Added");
			else
				System.out.println("Not Added");
	}catch(Exception e) {
			
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	@Override
	public List<Payee> showAll(int accNo) {
		List<Payee> l=new ArrayList<Payee>();
		
		try(Connection con=DBUtil.getConnection()) {
			String q="select * from payee where account_id=?";
			PreparedStatement st=con.prepareStatement(q);
			st.setLong(1,accNo);
			ResultSet rs=st.executeQuery();
			while(rs.next()) {
				Payee p=new Payee();
				p.setAccNo(rs.getInt("account_id"));
				p.setPayeeAccNo(rs.getInt("payee_account_id"));
				p.setName(rs.getString("nickname"));
				l.add(p);
			}
			
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return l;
	}
	
	
/*	public static void main(String args[]) {
		BankDao pdao=new BankDaoImpl();
		Payee p=new Payee();
		p.setAccNo(232);
		p.setPayeeAccNo(906);
		p.setName("Shikhar");
		pdao.add(p);
		p.setAccNo(105);
		pdao.add(p);
	}*/


}
