package com.cg.bankofcapgemini.service;

import java.util.List;

import com.cg.bankofcapgemini.dao.AdminDao;
import com.cg.bankofcapgemini.dao.AdminDaoImpl;
import com.cg.bankofcapgemini.dto.AccountHolder;
import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.exception.UserException;

public class AdminServiceImpl implements AdminService{
	
	AdminDao adminDao = new AdminDaoImpl();
	
	@Override
	public boolean createaccount(AccountHolder account) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.createaccount(account);
	}

	@Override
	public boolean checkadmin(String account, String password)
			throws UserException {
		// TODO Auto-generated method stub
		return adminDao.checkadmin(account, password);
	}

	@Override
	public List<TransactionDetails> viewtransaction() throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewtransaction();
	}

	@Override
	public String getAdminName(String admin_id) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getAdminName(admin_id);
	}

	@Override
	public int getuserid() throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getuserid();
	}

}
