package com.cg.bankofcapgemini.dto;

public class Customer {
	private long account_Id;
	private String name;
	private String Email;
	private String address;
	private String pancard;
	private String mobile;
	public long getAccount_Id() {
		return account_Id;
	}
	public void setAccount_Id(long account_Id) {
		this.account_Id = account_Id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		this.Email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Customer(long account_Id, String name, String email, String address,
			String pancard, String mobile) {
		super();
		this.account_Id = account_Id;
		this.name = name;
		this.Email = email;
		this.address = address;
		this.pancard = pancard;
		this.mobile = mobile;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Customer [account_Id=" + account_Id + ", name=" + name
				+ ", Email=" + Email + ", address=" + address + ", pancard="
				+ pancard + ", mobile=" + mobile + "]";
	}
	

}
