package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bankofcapgemini.dto.ServiceTracker;
import com.cg.bankofcapgemini.exception.UserException;
import com.cg.bankofcapgemini.factory.DBUtil;

public class RequestChequeBookDaoImpl implements RequestCheckBookDao {
	LoginDao loginDao = new LoginDaoImpl();
	
	public Long setServiceNumber(String user_id) throws UserException{
		int accountid = loginDao.getAccountId(user_id);
		ServiceTracker servicetracker = new ServiceTracker(); 
		Long id = (long) (Math.random()*1000000);
		boolean flag = false;
	try(Connection con = DBUtil.getConnection()){
			
			System.out.println(accountid);
			 PreparedStatement pstm = con.prepareStatement("update service_tracker set service_id=?,service_raised_date=sysdate,service_status='issued',service_description='CheckBookRequest',account_id=? where account_id=?and service_status='open'");
			 pstm.setLong(1, id);
			 pstm.setInt(2, accountid);
			 pstm.setInt(3, accountid);
				ResultSet res= pstm.executeQuery();
				
				
				if(res.next()){
					
					flag=true;
					
				}
				else{
					flag=false;
				}
			}catch (Exception e1){
				
				e1.printStackTrace();
				
			}
	if(flag==true)
		return id;
	else
		return 0l;
		
	}
	
	@Override
	public List<ServiceTracker> getServiceNumber(String user_id)throws UserException {
		int serviceRequestNo=0;
		int accountid = loginDao.getAccountId(user_id);
		List<ServiceTracker> myList = new ArrayList<ServiceTracker>();
		try(Connection con = DBUtil.getConnection()){
			
			System.out.println(accountid);
			 PreparedStatement pstm = con.prepareStatement("Select  Service_ID  from service_tracker where account_id=?");
			 pstm.setInt(1, accountid);
			
				ResultSet res= pstm.executeQuery();
				
				
				while(res.next()){
					ServiceTracker serviceTracker=new ServiceTracker();
					serviceTracker.setService_id(res.getInt("Service_ID"));	
					myList.add(serviceTracker);
				}
			
			}catch (Exception e1){
				
				e1.printStackTrace();
				
				
			}
System.out.println(myList);
		return myList;


	}


	//2.	To check the status of a particular request, please enter the Service Request number. 
	@Override
	public String getStatusOfSRN(int srn) throws UserException {
		String status=null;
	
	try(Connection con = DBUtil.getConnection()){
			
			System.out.println(srn);
			 PreparedStatement pstm = con.prepareStatement("Select  Service_status from service_tracker where Service_ID =?");
			 pstm.setInt(1, srn);
			
				ResultSet res= pstm.executeQuery();
				
				
				if(res.next()){
					System.out.println("heloo");
					status=res.getString("Service_status");
			 }
			}catch (Exception e1){
				
				e1.printStackTrace();
				
				
			}
		System.out.println(status);
		return status;

	}


	//3.	To check the status of all Service Requests OR If you do not remember the Service Request number, please select Account Number and click on submit option
	@Override
	public List<ServiceTracker> getStatusOfAllRequest(Long account_id,String user_id)
			throws UserException {
		List<ServiceTracker> myList = new ArrayList<ServiceTracker>();
		//int accountid = loginDao.getAccountId(user_id);
	//	Integer accountid = Integer.valueOf(account_id);
		Integer userid = Integer.valueOf(user_id);
	try(Connection con = DBUtil.getConnection()){
			
			System.out.println(account_id);
			 PreparedStatement pstm = con.prepareStatement("Select  Service_ID ,Service_status from service_tracker where Account_ID  =? and userid=?");
			 pstm.setLong(1, account_id);
			 pstm.setInt(2, userid);
				ResultSet res= pstm.executeQuery();
				while(res.next()){
					ServiceTracker serviceTracker=new ServiceTracker();
					serviceTracker.setService_id(res.getInt("Service_ID"));	
					serviceTracker.setService_status( res.getString("Service_status"));
					myList.add(serviceTracker);
				}
			
			}catch (Exception e1){
				
				e1.printStackTrace();
				
				
			}
	System.out.println("l ="+myList);
		return myList;

		
	}

	//4.	Only the latest 20 Service Requests raised in last 180 days will be displayed. 
	@Override
	public List<ServiceTracker> getLatest20ServiceRequest(String user_id)
			throws UserException {
		List<ServiceTracker> myList = new ArrayList<ServiceTracker>();
		int accountid = loginDao.getAccountId(user_id);
	try(Connection con = DBUtil.getConnection()){
			
			System.out.println(accountid);
			 PreparedStatement pstm = con.prepareStatement("Select Service_ID ,Service_Description ,Service_status,Service_Raised_Date from service_tracker where Account_ID  =? and ROWNUM<=20 AND Service_Raised_Date >= (SYSDATE-180) ");
			 pstm.setInt(1, accountid);
			
				ResultSet res= pstm.executeQuery();
				while(res.next()){
					ServiceTracker serviceTracker=new ServiceTracker();
					serviceTracker.setService_id(res.getInt("Service_ID"));	
					serviceTracker.setService_status( res.getString("Service_status"));
					serviceTracker.setService_description(res.getString("Service_Description"));	
					serviceTracker.setService_raised_date(res.getDate("Service_Raised_Date"));
					myList.add(serviceTracker);
				}
			
			}catch (Exception e1){
				
				e1.printStackTrace();
				
				
			}

		return myList;
	}
	
	public void updateServiceStatus(int accountid) throws UserException{
		
		 
		
	try(Connection con = DBUtil.getConnection()){
			
			System.out.println(accountid);
			 PreparedStatement pstm = con.prepareStatement("update service_tracker set service_status='open' where account_id=?");
			
			 pstm.setInt(1, accountid);
			
				pstm.executeUpdate();
			}catch (Exception e1){
				
				e1.printStackTrace();
				
			}
		
		
	}
}
