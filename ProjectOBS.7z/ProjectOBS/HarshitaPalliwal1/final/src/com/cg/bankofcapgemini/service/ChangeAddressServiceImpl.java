package com.cg.bankofcapgemini.service;

import com.cg.bankofcapgemini.dao.ChangeAddressDao;
import com.cg.bankofcapgemini.dao.ChangeAddressDaoImpl;
import com.cg.bankofcapgemini.dto.Customer;
import com.cg.bankofcapgemini.exception.UserException;

public class ChangeAddressServiceImpl implements ChangeAddressService {
	ChangeAddressDao addressDao = new ChangeAddressDaoImpl();
	@Override
	public Customer getAddressMobile(String user_id) throws UserException {
		
		return addressDao.getAddressMobile(user_id);
	}

	@Override
	public boolean changeAddress(String user_id, String address) throws UserException {
		
		return addressDao.changeAddress(user_id, address);
	}

	@Override
	public boolean changeMobile(String user_id, String mobile) throws UserException {
		// TODO Auto-generated method stub
		return addressDao.changeMobile(user_id, mobile);
	}

}
