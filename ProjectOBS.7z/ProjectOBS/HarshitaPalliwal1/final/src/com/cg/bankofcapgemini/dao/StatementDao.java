package com.cg.bankofcapgemini.dao;

import java.util.List;

import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.exception.UserException;

public interface StatementDao {
	public List<TransactionDetails> miniStatement(String user_id)throws UserException;
	
	public List<TransactionDetails> detailStatement(String user_id)throws UserException;
}
