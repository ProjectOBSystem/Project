package com.cg.bankofcapgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import javax.transaction.Transaction;

import com.cg.bankofcapgemini.dto.TransactionDetails;
import com.cg.bankofcapgemini.dto.otherBanks;
import com.cg.bankofcapgemini.factory.DBUtil;



public class TransactionDaoImpl implements TransactionDao {

	@Override
	public void insert(TransactionDetails transaction,int accNo) {
		
		
		PreparedStatement pt=null;
		Connection con=null;
		String accountType=null;
			try {
				con=DBUtil.getConnection();
				
				String q1="Select * from account_master  where account_id=?";
				PreparedStatement pstm=con.prepareStatement(q1);
				pstm.setLong(1,accNo);
				ResultSet res = pstm.executeQuery();
				
				if(res.next()) {
					accountType=res.getString("account_type");
					
				}
				System.out.println(accountType);
				
				String query="insert into transactions values(?,?,?,?,?,?)";
				pt = con.prepareStatement(query);
				int transactionId=getTransactionId();
				System.out.println(transactionId);
				pt.setInt(1,transactionId);
				//pt.setString(4,Character.toString(t.getTransactionType()));
				pt.setString(2,transaction.getTran_Description());
				String q3="Select sysdate from dual";
				java.sql.Statement st=con.createStatement();
				ResultSet rs=st.executeQuery(q3);
				while(rs.next()) 
				{
					pt.setDate(3,rs.getDate(1));	
				}
				pt.setString(4,"D");
				pt.setDouble(5,transaction.getTranAmount());
				pt.setLong(6,transaction.getAccount_ID());

				int i=pt.executeUpdate();
				System.out.println("Das");
				if(i==1){
					System.out.println("true");
				}
				else
					System.out.println("false");
			} catch (SQLException | ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			finally {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		
		
	}
	

	public int getTransactionId() {
		int tid=0;
		java.sql.Statement st;
		try {
			Connection con=DBUtil.getConnection();
			String q="select trans_seq.nextval from dual";
			st = con.createStatement();
			ResultSet rs=st.executeQuery(q);
			while(rs.next()) 
			   {
				  tid=rs.getInt(1);
				  return tid;
			   }
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tid;
	}

}
