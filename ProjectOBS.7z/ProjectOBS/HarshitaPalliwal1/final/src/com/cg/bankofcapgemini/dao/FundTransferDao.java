package com.cg.bankofcapgemini.dao;

import com.cg.bankofcapgemini.dto.FundTransfer;



public interface FundTransferDao {
	public void insert(FundTransfer ft );
}
